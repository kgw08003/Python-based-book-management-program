import os

CATEGORIES_FILE = './txt/categories.txt'

def manageCategoriesMenu():
    os.system('cls')

    print("=========카테고리 관리=========")
    print("1: 카테고리 추가")
    print("2: 카테고리 삭제")
    print("3: 카테고리 목록 보기")
    print("0: 뒤로가기")
    print()
    return input("메뉴 선택: ")

def addCategory():
    print("=========카테고리 추가=========")
    category = input("카테고리명: ")
    
    with open(CATEGORIES_FILE, 'a') as file:
        file.write(f"{category}\n")
    
    print(f"카테고리 '{category}'이(가) 추가되었습니다.")

def delCategory():
    print("=========카테고리 삭제=========")
    category_to_delete = input("삭제할 카테고리명: ")
    
    with open(CATEGORIES_FILE, 'r') as file:
        lines = file.readlines()
    
    with open(CATEGORIES_FILE, 'w') as file:
        for line in lines:
            if line.strip() != category_to_delete:
                file.write(line)
    
    print(f"카테고리 '{category_to_delete}'이(가) 삭제되었습니다.")

def viewCategories():
    print("=========카테고리 목록=========")
    with open(CATEGORIES_FILE, 'r') as file:
        lines = file.readlines()
    
    print("카테고리 목록:")
    for line in lines:
        print(line.strip())

def manageCategories():
    while True:
        submenu = manageCategoriesMenu()
        if submenu == "0":
            break
        elif submenu == "1":
            addCategory()
        elif submenu == "2":
            delCategory()
        elif submenu == "3":
            viewCategories()
        else:
            print("메뉴를 잘못 선택했습니다!")
        input("아무 키나 눌러주세요...")

import os

BORROW_RECORDS_FILE = './txt/borrow_records.txt'

def manageBorrowRecordsMenu():
    os.system('cls')

    print("=========대출 기록 관리=========")
    print("1: 대출 기록 저장")
    print("2: 반납 기록 저장")
    print("3: 과거 대출/반납 기록 조회")
    print("0: 뒤로가기")
    print()
    return input("메뉴 선택: ")

def saveBorrowRecord():
    print("=========대출 기록 저장=========")
    member_id = input("회원 ID: ")
    book_isbn = input("도서 ISBN: ")
    borrow_date = input("대출일: ")
    
    with open(BORROW_RECORDS_FILE, 'a') as file:
        file.write(f"{member_id},{book_isbn},{borrow_date},\n")
    
    print(f"회원 ID '{member_id}'이(가) 도서 ISBN '{book_isbn}'을(를) 대출했습니다.")

def saveReturnRecord():
    print("=========반납 기록 저장=========")
    member_id = input("회원 ID: ")
    book_isbn = input("도서 ISBN: ")
    return_date = input("반납일: ")
    
    with open(BORROW_RECORDS_FILE, 'a') as file:
        file.write(f"{member_id},{book_isbn},,{return_date}\n")
    
    print(f"회원 ID '{member_id}'이(가) 도서 ISBN '{book_isbn}'을(를) 반납했습니다.")

def viewPastRecords():
    print("=========과거 대출/반납 기록 조회=========")
    member_id = input("회원 ID: ")
    
    with open(BORROW_RECORDS_FILE, 'r') as file:
        lines = file.readlines()
    
    print(f"회원 ID '{member_id}'의 대출/반납 기록:")
    for line in lines:
        parts = line.strip().split(',')
        if parts[0] == member_id:
            print(f"도서 ISBN: {parts[1]}, 대출일: {parts[2]}, 반납일: {parts[3]}")
    
    if not any(line.startswith(member_id) for line in lines):
        print("기록이 없습니다.")

def manageBorrowRecords():
    while True:
        submenu = manageBorrowRecordsMenu()
        if submenu == "0":
            break
        elif submenu == "1":
            saveBorrowRecord()
        elif submenu == "2":
            saveReturnRecord()
        elif submenu == "3":
            viewPastRecords()
        else:
            print("메뉴를 잘못 선택했습니다!")
        input("아무 키나 눌러주세요...")

import os

MEMBERS_FILE = './txt/members.txt'

def manageMembersMenu():
    os.system('cls' if os.name == 'nt' else 'clear')

    print("=========회원 정보 관리=========")
    print("1: 회원 정보 추가")
    print("2: 회원 정보 수정")
    print("3: 회원 정보 삭제")
    print("4: 회원 대출 현황")
    print("0: 뒤로가기")
    print()
    return input("메뉴 선택: ")

def addMember():
    print("=========회원 정보 추가=========")
    name = input("회원명: ")
    member_id = input("회원 ID: ")
    contact = input("연락처: ")
    email = input("이메일: ")
    
    with open(MEMBERS_FILE, 'a') as file:
        file.write(f"{member_id},{name},{contact},{email}\n")
    
    print(f"회원 '{name}'이(가) 추가되었습니다.")

def editMember():
    print("=========회원 정보 수정=========")
    member_id_to_edit = input("수정할 회원의 ID: ")
    
    with open(MEMBERS_FILE, 'r') as file:
        lines = file.readlines()
    
    with open(MEMBERS_FILE, 'w') as file:
        for line in lines:
            parts = line.strip().split(',')
            if parts[0] == member_id_to_edit:
                new_name = input("새 회원명: ")
                new_contact = input("새 연락처: ")
                new_email = input("새 이메일: ")
                file.write(f"{member_id_to_edit},{new_name},{new_contact},{new_email}\n")
            else:
                file.write(line)
    
    print(f"회원 ID '{member_id_to_edit}'의 정보가 수정되었습니다.")

def deleteMember():
    print("=========회원 정보 삭제=========")
    member_id_to_delete = input("삭제할 회원의 ID: ")
    
    with open(MEMBERS_FILE, 'r') as file:
        lines = file.readlines()
    
    with open(MEMBERS_FILE, 'w') as file:
        for line in lines:
            if not line.startswith(member_id_to_delete):
                file.write(line)
    
    print(f"회원 ID '{member_id_to_delete}'이(가) 삭제되었습니다.")

def viewMemberBorrowing():
    print("=========회원 대출 현황=========")
    member_id = input("회원 ID: ")
    
    print(f"회원 ID '{member_id}'의 대출 현황을 조회합니다.")

def manageMembers():
    while True:
        submenu = manageMembersMenu()
        if submenu == "0":
            break
        elif submenu == "1":
            addMember()
        elif submenu == "2":
            editMember()
        elif submenu == "3":
            deleteMember()
        elif submenu == "4":
            viewMemberBorrowing()
        else:
            print("메뉴를 잘못 선택했습니다!")
        input("아무 키나 눌러주세요...")

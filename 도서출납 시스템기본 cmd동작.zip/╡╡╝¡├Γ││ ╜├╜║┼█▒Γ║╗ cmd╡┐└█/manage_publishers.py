import os

PUBLISHERS_FILE = './txt/publishers.txt'

def managePublishersMenu():
    os.system('cls')

    print("=========출판사 관리=========")
    print("1: 출판사 추가")
    print("2: 출판사 삭제")
    print("3: 출판사 목록 보기")
    print("0: 뒤로가기")
    print()
    return input("메뉴 선택: ")

def addPublisher():
    print("=========출판사 추가=========")
    publisher = input("출판사명: ")
    
    with open(PUBLISHERS_FILE, 'a') as file:
        file.write(f"{publisher}\n")
    
    print(f"출판사 '{publisher}'이(가) 추가되었습니다.")

def delPublisher():
    print("=========출판사 삭제=========")
    publisher_to_delete = input("삭제할 출판사명: ")
    
    with open(PUBLISHERS_FILE, 'r') as file:
        lines = file.readlines()
    
    with open(PUBLISHERS_FILE, 'w') as file:
        for line in lines:
            if line.strip() != publisher_to_delete:
                file.write(line)
    
    print(f"출판사 '{publisher_to_delete}'이(가) 삭제되었습니다.")

def viewPublishers():
    print("=========출판사 목록=========")
    with open(PUBLISHERS_FILE, 'r') as file:
        lines = file.readlines()
    
    print("출판사 목록:")
    for line in lines:
        print(line.strip())

def managePublishers():
    while True:
        submenu = managePublishersMenu()
        if submenu == "0":
            break
        elif submenu == "1":
            addPublisher()
        elif submenu == "2":
            delPublisher()
        elif submenu == "3":
            viewPublishers()
        else:
            print("메뉴를 잘못 선택했습니다!")
        input("아무 키나 눌러주세요...")

import os
import manage_categories
import manage_publishers

BOOKS_FILE = './txt/books.txt'

def manageBooksMenu():
    os.system('cls')

    print("=========도서정보 관리=========")
    print("1: 도서 추가")
    print("2: 도서 삭제")
    print("3: 도서 검색")
    print("4: 카테고리 관리")
    print("5: 출판사 관리")
    print("0: 뒤로가기")
    print()
    return input("메뉴 선택: ")

def addBook():
    print("=========도서 추가=========")
    title = input("도서명: ")
    author = input("저자명: ")
    publisher = input("출판사: ")
    isbn = input("ISBN: ")
    publication_year = input("발행년도: ")
    category = input("카테고리: ")
    
    with open(BOOKS_FILE, 'a') as file:
        file.write(f"{isbn},{title},{author},{publisher},{publication_year},{category}\n")
    
    print(f"도서 '{title}'이(가) 추가되었습니다.")

def delBook():
    print("=========도서 삭제=========")
    isbn_to_delete = input("삭제할 도서의 ISBN: ")
    
    with open(BOOKS_FILE, 'r') as file:
        lines = file.readlines()
    
    with open(BOOKS_FILE, 'w') as file:
        for line in lines:
            if not line.startswith(isbn_to_delete):
                file.write(line)
    
    print(f"도서 ISBN '{isbn_to_delete}'이(가) 삭제되었습니다.")

def searchBookMenu():
    os.system('cls')

    print("=========도서 검색=========")
    print("1: 도서명 검색")
    print("2: 저자명 검색")
    print("3: 출판사 검색")
    print("4: ISBN 검색")
    print("5: 발행년도 검색")
    print("6: 카테고리 검색")
    print("0: 뒤로가기")
    print()
    return input("메뉴 선택: ")

def searchBook():
    while True:
        menu = searchBookMenu()
        if menu == "0":
            break
        query = input("검색어 입력: ")
        
        with open(BOOKS_FILE, 'r') as file:
            lines = file.readlines()
        
        for line in lines:
            parts = line.strip().split(',')
            if menu == "1" and query.lower() in parts[1].lower():
                print(line.strip())
            elif menu == "2" and query.lower() in parts[2].lower():
                print(line.strip())
            elif menu == "3" and query.lower() in parts[3].lower():
                print(line.strip())
            elif menu == "4" and query in parts[0]:
                print(line.strip())
            elif menu == "5" and query in parts[4]:
                print(line.strip())
            elif menu == "6" and query.lower() in parts[5].lower():
                print(line.strip())
        
        if menu not in ["1", "2", "3", "4", "5", "6"]:
            print("메뉴를 잘못 선택했습니다!")
        
        input("아무 키나 눌러주세요...")

def manageBooks():
    while True:
        submenu = manageBooksMenu()
        if submenu == "0":
            break
        elif submenu == "1":
            addBook()
        elif submenu == "2":
            delBook()
        elif submenu == "3":
            searchBook()
        elif submenu == "4":
            manage_categories.manageCategories()
        elif submenu == "5":
            manage_publishers.managePublishers()
        else:
            print("메뉴를 잘못 선택했습니다!")
        input("아무 키나 눌러주세요...")

import os
import manage_books
import manage_members
import manage_borrow_records

# 공통 메뉴
def selectMenu():
    os.system('cls')

    print("===========================")
    print("도서관리 프로그램 ver. 0.1.0")
    print("===========================")
    print()
    print("1: 도서정보 관리")
    print("2: 회원 정보 관리")
    print("3: 대출 기록 관리")
    print("0: 종료")
    print()
    return input("메뉴 선택: ")

# 메인 메뉴
def main():
    while True:
        menu = selectMenu()

        if menu == "0":
            break
        elif menu == "1":
            manage_books.manageBooks()
        elif menu == "2":
            manage_members.manageMembers()
        elif menu == "3":
            manage_borrow_records.manageBorrowRecords()
        else:
            print("메뉴를 잘못 선택했습니다!")
            input("아무 키나 눌러주세요...")

    print("프로그램을 종료합니다.")

if __name__ == '__main__':
    main()
